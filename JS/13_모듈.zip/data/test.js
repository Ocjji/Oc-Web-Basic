// data

let arr = ['보라돌이', '뚜비', '나나', '뽀', '아가햇님'];

export default arr;
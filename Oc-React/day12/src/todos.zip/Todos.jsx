import React from 'react';
import TodoForm from "./TodoForm";
import TodoList from "./TodoList";

const Todos = () => {
    return (
        <div>
            <h1>일정 관리하기</h1>
            <TodoForm />
            <TodoList />
        </div>
    );
};

export default Todos;
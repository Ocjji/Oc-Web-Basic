import React from 'react';

const TodoItem = () => {
    return (
        <li>
            <input type="checkbox" />
            내용
            <button>삭제</button>
        </li>
    );
};

export default TodoItem;
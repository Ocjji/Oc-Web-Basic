import React from 'react';

const TodoForm = () => {
    return (
        <div>
            <input type="text" />
        </div>
    );
};

export default TodoForm;